var newusername=document.getElementById("newusername");
var newpassword=document.getElementById("newpassword");
var submit=document.getElementById("submit");

//form validation
function validateForm(){
  var checker = true;
  if(newusername.value == "" && newpassword.value == "" )
  {
  alert("Please do not leave the fields empty")
  checker = false;
  }
  else
{
  if(!(newusername.value.length >= 4))
  {
    alert("Username must be longer than 3 characters");
    checker = false;
  }
  var userchar = /^[0-9a-zA-Z]+$/
  if(!(newusername.value.match(userchar)))
  {
  alert("Username can only consist of characters and numbers")
  checker = false;
  }
  var pwchar = /[a-zA-Z]/g
  var pwnum = /[0-9]/g
  if(!(newpassword.value.match(pwchar))||!(newpassword.value.match(pwnum))||!(newpassword.value.length >=6 && newpassword.value.length <=15))
  {
  alert("The length of the password must be between 6 to 15 characters and it must consist of only alphanumerical characters with at least one alphabet and one numerical character")
  checker = false;
  }
}
return checker;
}
