
//jquery ajax get request to retrieve comment
$("#recomment").click(function() {
  var id = $("#filmtocomment").val();
  var display = "";
  $.ajax({
      type: 'GET',
      url: '/main/comment_retrieve/'+id,
      dataType: 'json',
  }).done(function(res){
    $.each(res, function () {
        display+="<div>Viewer: "+this.userid+"<br>Comment: "+this.comment+"<br><hr></div>";
    });
    $('#entries').html(display);
  })
});
