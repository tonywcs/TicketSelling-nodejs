//seatplan validation: check if chose any seat
function validate()
{
var chks = document.getElementsByName('seatarray[]');
var hasChecked = false;
for (var i = 0; i < chks.length; i++)
{
	if (chks[i].checked)
	{
	hasChecked = true;
	break;
	}
}

if (hasChecked == false)
	{
	alert("Please select at least one.");
	return false;
	}

return true;
}
