var username=document.getElementById("username");
var password=document.getElementById("password");
var submit=document.getElementById("submit");

//form validation
submit.addEventListener("click", function (event)
{
if(!username.checkValidity() || !password.checkValidity())
{
alert("Please do not leave the fields empty")
}
})
