const {User} = require('../models/user');
const mongoose = require('mongoose');
const express = require('express');
const router = express.Router();

//add new user
router.post('/new', async (req, res) => {

  let user = await User.findOne({ username: req.body.newusername });
  if (user) return res.send('<meta http-equiv="refresh" content="3;url=/create"><h1>User already registered. Page redirecting in 3 seconds.</h1>');

  user = new User({
    username: req.body.newusername,
    password: req.body.newpassword
  });
  await user.save();

  res.send('<meta http-equiv="refresh" content="3;url=/"><h1>Registration successful. Page redirecting in 3 seconds.</h1>');
});

//handle login
router.post('/auth', async (req, res) => {

  const user = await User.findOne({ username: req.body.username });
  if (!user) return res.send('<meta http-equiv="refresh" content="3;url=/"><h1>Invalid username or password. Page redirecting in 3 seconds.</h1>');

  if(req.body.password != user.password)
  return res.send('<meta http-equiv="refresh" content="3;url=/"><h1>Invalid username or password. Page redirecting in 3 seconds.</h1>');

  req.session.login = user.username;
  console.log(req.session.login);
  res.send('<meta http-equiv="refresh" content="0;url=/main">');
});

module.exports = router;
