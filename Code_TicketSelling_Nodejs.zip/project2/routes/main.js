var express = require('express');
var router = express.Router();
//connect database's collection
const {Film} = require('../models/film');
const {Broadcast} = require('../models/broadcast');
const {House} = require('../models/house');
const {Ticket} = require('../models/ticket');
const {Comment} = require('../models/comment');

//Go to main page after login
router.get('/', function(req, res, next) {
  if(req.session.login) res.render('main');

  else res.send('<meta http-equiv="refresh" content="3;url=/"><h1>You have not logged in. Page redirecting in 3 seconds.</h1>');
});

//-------------------------------Buy a ticket----------

//Go to buywelcome page and display movies
router.get('/buywelcome', function(req, res, next) {
  if(!req.session.login) return res.send('<meta http-equiv="refresh" content="3;url=/"><h1>You have not logged in. Page redirecting in 3 seconds.</h1>');

  Film.find(function(error, filmresult){
    Broadcast.find(function(error, broadresult){
      res.render('buywelcome',{filmdata:filmresult, broaddata: broadresult});
    });
  });
});

//Go to seatplantry page after chose movie
router.post('/seatplantry', async (req, res, next) =>{
  if(!req.session.login)
  return res.send('<meta http-equiv="refresh" content="3;url=/"><h1>You have not logged in. Page redirecting in 3 seconds.</h1>');

    req.session.broadcastid = req.body.choice;
    const broadcast = await Broadcast.findOne({ broadcastid: req.body.choice});
    const film = await Film.findOne({filmid: broadcast.filmid});
    const house = await House.findOne({House: broadcast.house});
    const ticket = await Ticket.find({broadcastid: broadcast.broadcastid});
    res.render('seatplantry',{broaddata: broadcast, filmdata: film, housedata: house, ticketdata: ticket});
});

//Go to buyticket page after select seat
router.post('/buyticket', async (req, res, next) =>{
  if(!req.session.login)
  return res.send('<meta http-equiv="refresh" content="3;url=/"><h1>You have not logged in. Page redirecting in 3 seconds.</h1>');

  req.session.seatchosen = req.body.seatarray;

  const broadcast = await Broadcast.findOne({ broadcastid: req.session.broadcastid});
  const film = await Film.findOne({filmid: broadcast.filmid});
  res.render('buyticket',{broaddata: broadcast, filmdata: film, seatdata: req.body.seatarray});
});

//Go to confirm page after select ticket type
router.post('/confirm', async (req, res, next) =>{
  if(!req.session.login)
  return res.send('<meta http-equiv="refresh" content="3;url=/"><h1>You have not logged in. Page redirecting in 3 seconds.</h1>');

  var feearray = []
  total = 0;
  for(i=0;i<req.session.seatchosen.length;i++)
  {
    if(req.body.ticketarray[i] == "Adult"){
    feearray[i] = 75;
    total = total + feearray[i];
    }
    else {
    feearray[i] = 50;
    total = total + feearray[i];
    }
  const ticket = await Ticket.findOne({seatno: req.session.seatchosen[i], broadcastid: req.session.broadcastid});
  ticket.tickettype = req.body.ticketarray[i];
  ticket.ticketfee = feearray[i];
  ticket.valid = "N";
  ticket.userid = req.session.login;
  await ticket.save();
  }

  const broadcast = await Broadcast.findOne({ broadcastid: req.session.broadcastid});
  const film = await Film.findOne({filmid: broadcast.filmid});

  res.render('confirm',{broaddata: broadcast, filmdata: film, seatdata: req.session.seatchosen, typedata: req.body.ticketarray, feedata: feearray, total: total});

});

//-------------------------------Comment----------

//Go to comment page
router.get('/comment', async (req, res, next) =>{
  if(!req.session.login)
  return res.send('<meta http-equiv="refresh" content="3;url=/"><h1>You have not logged in. Page redirecting in 3 seconds.</h1>');

  const film = await Film.find();
  res.render('comment',{filmdata: film});
});

//Handle the comment submitted by client
router.post('/comment_submit', async (req, res, next) =>{
  if(!req.session.login)
  return res.send('<meta http-equiv="refresh" content="3;url=/"><h1>You have not logged in. Page redirecting in 3 seconds.</h1>');

  comment = new Comment({
    filmid: req.body.filmtocomment,
    userid: req.session.login,
    comment: req.body.comment
  });
  await comment.save();

  return res.send('<meta http-equiv="refresh" content="3;url=/main/comment"><h1>You comment has been received. Page redirecting in 3 seconds.</h1>');
});

//Handle the comment retrieve ajax request by client
router.get('/comment_retrieve/:id', async (req, res) =>{
  if(!req.session.login)
  return res.send('<meta http-equiv="refresh" content="3;url=/"><h1>You have not logged in. Page redirecting in 3 seconds.</h1>');

      var film = req.params.id;
      var comment = await Comment.find({filmid:film});
      res.json(comment);
});

//-------------------------------Display ticket history----------

//Go to history page and display ticket history
router.get('/history', async (req, res) =>{
if(!req.session.login)
return res.send('<meta http-equiv="refresh" content="3;url=/"><h1>You have not logged in. Page redirecting in 3 seconds.</h1>');

  var ticket = await Ticket.find({userid: req.session.login});
  var broadcast = await Broadcast.find();
  var film = await Film.find();

return res.render('history',{username:req.session.login, ticketdata:ticket, broaddata: broadcast, filmdata: film});
});

//-------------------------------Logout----------

//Handle the logout request
router.get('/logout', async (req, res) =>{
if(!req.session.login)
return res.send('<meta http-equiv="refresh" content="3;url=/"><h1>You have not logged in. Page redirecting in 3 seconds.</h1>');

req.session.destroy();
return res.send('<meta http-equiv="refresh" content="3;url=/"><h1>Logging out... Redirecting in 3 seconds.</h1>');
});

module.exports = router;
