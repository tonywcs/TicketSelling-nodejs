const jwt = require('jsonwebtoken');
const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  username: {
    type: String,
    required: true,
    minlength: 4,
    maxlength: 25
  },
  password: {
    type: String,
    required: true,
    minlength: 5,
    maxlength: 15
  },
});

userSchema.methods.generateAuthToken = function() {
  const token = jwt.sign({ _id: this._id}, 'jwtPrivateKey');
  return token;
}

const User = mongoose.model('Users', userSchema);

exports.User = User;
