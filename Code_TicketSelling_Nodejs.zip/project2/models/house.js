const mongoose = require('mongoose');

const House = mongoose.model('Houses', new mongoose.Schema({
  house: {
    type: String
  },
  houserow: {
    type: Number
  },
  housecol: {
    type: Number
  }
}));

exports.House = House;
