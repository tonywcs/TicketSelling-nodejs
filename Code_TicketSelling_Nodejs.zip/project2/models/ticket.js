const mongoose = require('mongoose');

const Ticket = mongoose.model('Tickets', new mongoose.Schema({
  seatno: {
    type: String,
  },
  broadcastid: {
    type: String
  },
  valid:{
    type: String
  },
  userid:{
    type: String
  },
  tickettype:{
    type: String
  },
  ticketfee:{
    type: Number
  }
}));

exports.Ticket = Ticket;
