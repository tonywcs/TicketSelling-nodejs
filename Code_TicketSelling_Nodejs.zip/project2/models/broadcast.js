const mongoose = require('mongoose');

const Broadcast = mongoose.model('Broadcasts', new mongoose.Schema({
  broadcastid: {
    type: Number,
  },
  dates: {
    type: String,
  },
  time: {
    type: String
  },
  film_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Films'
  },
  filmid: {
    type: Number
  },
  houseid: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Houses'
  },
  house: {
    type: String
  },
  day:{
    type: String
  }
}));

exports.Broadcast = Broadcast;
