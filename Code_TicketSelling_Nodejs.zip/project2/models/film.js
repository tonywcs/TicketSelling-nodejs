const mongoose = require('mongoose');

const Film = mongoose.model('Films', new mongoose.Schema({
  filmid: {
    type: Number
  },
  name: {
    type: String,
    required: true,
  },
  duration: {
    type: String
  },
  category: {
    type: String
  },
  language: {
    type: String
  },
  director:{
    type: String
  },
  description:{
    type: String
  }
}));

exports.Film = Film;
