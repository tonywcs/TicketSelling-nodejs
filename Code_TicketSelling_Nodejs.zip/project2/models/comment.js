const mongoose = require('mongoose');

const Comment = mongoose.model('Comments', new mongoose.Schema({
  filmid: {
    type: Number
  },
  userid: {
    type: String
  },
  comment:{
    type: String
  }
}));

exports.Comment = Comment;
